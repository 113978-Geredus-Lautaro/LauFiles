package com.example.APICompletaLabo.repositories.jpa;


import com.example.APICompletaLabo.Entities.PlayerEntity;
import com.example.APICompletaLabo.jpa.PlayerJpaRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import java.util.Optional;

@DataJpaTest
public class PlayerJpaRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private PlayerJpaRepository pLayerJpaRepository;

    @Test
    public void findByUserNameOrEmailTest(){
        PlayerEntity playerEntity = new PlayerEntity();
        playerEntity.setEmail("hola@gmail.com");
        playerEntity.setUserName("Maximo");
        playerEntity.setPassword("Maximo457$");


        entityManager.persist(playerEntity);
        entityManager.flush();

        Optional<PlayerEntity> result =
                pLayerJpaRepository.findByUserNameOrEmail("Maximo","hola@gmail.com");
        Assertions.assertEquals("Maximo", result.get().getUserName());

    }
}
