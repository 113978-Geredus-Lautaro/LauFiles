INSERT INTO Players (user_name, user_password, email, avatar, last_login, created_at, update_at)
VALUES ('APP', null, null, null, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

INSERT INTO Players (user_name, user_password, email, avatar, last_login, created_at, update_at)
VALUES ('Maximo', 'Maximo347$', 'hola@gmail.com', null, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

INSERT INTO Players (user_name, user_password, email, avatar, last_login, created_at, update_at)
VALUES ('Ignacio', 'Ignacio347$', 'papa@gmail.com', null, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

INSERT INTO games (code, name ,description, rules)
VALUES ('RPS' , 'Rock Paper Scissors',
        'Este es el juego de piedra papel o tijera',
        'TODOS SABEN LAS REGLAS DE ESTO PA');



INSERT INTO matches(game_id, player1_id, player2_id, created_at, updated_at, status)
VALUES (1, 2,1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'STARTED');

INSERT INTO matches(game_id, player1_id, player2_id, created_at, updated_at, status)
VALUES (1, 2,3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'FINISHED');

INSERT INTO matches(game_id, player1_id, player2_id , created_at, updated_at, status)
VALUES (1, 2,3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'CANCELED');


INSERT INTO matches_rps(id,number_of_plays,remainder_plays,player1score,player2score)
VALUES (1,3,2,1,0);

INSERT INTO matches_rps(id,number_of_plays,remainder_plays,player1score,player2score,winner_id)
VALUES (2,3,0,2,1,2);

INSERT INTO matches_rps(id,number_of_plays,remainder_plays,player1score,player2score)
VALUES (3,3,1,1,1);

INSERT INTO plays_rps(match_rps_id,shape_hand_player1,shape_hand_player2, winner_id)
VALUES (1,'ROCK','SCISSORS',2);

INSERT INTO plays_rps(match_rps_id,shape_hand_player1,shape_hand_player2, winner_id)
VALUES (2,'ROCK','SCISSORS',2);

INSERT INTO plays_rps(match_rps_id,shape_hand_player1,shape_hand_player2, winner_id)
VALUES (2,'SCISSORS','ROCK',1);

INSERT INTO plays_rps(match_rps_id,shape_hand_player1,shape_hand_player2, winner_id)
VALUES (2,'ROCK','SCISSORS',2);


