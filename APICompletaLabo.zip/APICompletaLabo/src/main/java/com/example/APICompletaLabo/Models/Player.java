package com.example.APICompletaLabo.Models;

import com.example.APICompletaLabo.utils.validations.password.ValidPassword;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Player {


    private Long id;
    @NotNull(message = "userName can't by null")
    private String userName;
    @NotNull(message = "password can't by null")
    @ValidPassword
    private String password;
    @NotNull(message = "Email can't by null")
    @Email(message = "The email need to be valid email")
    private String email;

    private String avatar;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
    private LocalDateTime lastLoginDate;

}
