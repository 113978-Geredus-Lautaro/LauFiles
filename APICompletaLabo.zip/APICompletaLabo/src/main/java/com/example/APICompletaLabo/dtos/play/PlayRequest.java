package com.example.APICompletaLabo.dtos.play;


import com.example.APICompletaLabo.Models.rps.MatchRps;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(use = JsonTypeInfo.Id.DEDUCTION)
@JsonSubTypes({
        @JsonSubTypes.Type(value = PlayRpsDTO.class)
})
public interface PlayRequest {
}
