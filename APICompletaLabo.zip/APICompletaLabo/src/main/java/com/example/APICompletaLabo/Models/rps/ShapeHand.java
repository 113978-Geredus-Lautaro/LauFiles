package com.example.APICompletaLabo.Models.rps;

public enum ShapeHand {

    ROCK, PAPER, SCISSORS
}
