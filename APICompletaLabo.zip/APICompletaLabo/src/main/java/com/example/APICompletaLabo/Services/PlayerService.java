package com.example.APICompletaLabo.Services;

import com.example.APICompletaLabo.Models.Match;
import com.example.APICompletaLabo.Models.Player;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface PlayerService {
    Player getPlayerById(long id);
    Player savePlayer(Player player);
    Player getPlayerByUserNameAndPassword(String userName, String password);
    Player getPlayerByEmailAndPassword(String email, String password);
    Player getPlayerByUserNameOrEmailAndPassword(String identity, String password);


}
