package com.example.APICompletaLabo.Services.impl;

import com.example.APICompletaLabo.Entities.MatchEntity;
import com.example.APICompletaLabo.Models.*;
import com.example.APICompletaLabo.Models.rps.MatchRps;
import com.example.APICompletaLabo.Services.Factory.MatchEntityFactory;
import com.example.APICompletaLabo.Services.Factory.MatchFactory;
import com.example.APICompletaLabo.Services.Factory.PlayFactory;
import com.example.APICompletaLabo.Services.Factory.PlayStrategyFactory;
import com.example.APICompletaLabo.Services.GameService;
import com.example.APICompletaLabo.Services.MatchService;
import com.example.APICompletaLabo.Services.PlayMatch;
import com.example.APICompletaLabo.Services.PlayerService;
import com.example.APICompletaLabo.dtos.matches.MatchDTO;
import com.example.APICompletaLabo.dtos.play.PlayRequest;
import com.example.APICompletaLabo.jpa.MatchJpaRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.hibernate.Hibernate;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class MatchServiceImpl implements MatchService {


    @Autowired
    private MatchJpaRepository matchJpaRepository;
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private PlayerService playerService;
    @Autowired
    private GameService gameService;
    @Autowired
    private PlayStrategyFactory playStrategyFactory;

    @Override
    public List<Match> getMatchesByPlayer(Long player_id) {
        List<Match> matches = new ArrayList<>();
        Optional<List<MatchEntity>> optionalMatchEntities =  matchJpaRepository.getAllByPlayer(player_id);

        if(optionalMatchEntities.isPresent()){

           for(MatchEntity me : optionalMatchEntities.get()){
               matches.add(modelMapper.map(me, MatchFactory.getMatchInstance(me.getGame().getCode()).getClass()));
           }

           return matches;
        }
        return matches;
    }

    @Override
    public Match getMatchById(Long id) {

        MatchEntity me = (MatchEntity) Hibernate.unproxy(matchJpaRepository.getReferenceById(id));
        if(me != null){
            Match match = modelMapper.map(me, MatchFactory.getTypeOfMatch(me.getGame().getCode()));
            return match;
        }
        else
            throw new EntityNotFoundException();
    }


    @Override
    public Match createMatch(MatchDTO matchDTO) {

        Player player = playerService.getPlayerById(matchDTO.getPlayerId());
        Game game = gameService.getGame(matchDTO.getGameId());
        Match match = MatchFactory.createMatch(player,game);
        MatchEntity matchEntity = matchJpaRepository.save(modelMapper.map(match, MatchEntityFactory.getTypeOfMatch(match)));
        return modelMapper.map(matchEntity, match.getClass());
    }

    @Transactional
    @Override
    public Play play(Long matchId, PlayRequest playRequest) {
        Match match = this.getMatchById(matchId);

        if(match == null){
            throw new EntityNotFoundException();
        }
        Play play = PlayFactory.getPlayInstance(playRequest, match.getGame().getCode());
        PlayMatch playMatch = playStrategyFactory.getPlayStrategy(match.getGame().getCode());
        return playMatch.play(play,match);
    }
}
