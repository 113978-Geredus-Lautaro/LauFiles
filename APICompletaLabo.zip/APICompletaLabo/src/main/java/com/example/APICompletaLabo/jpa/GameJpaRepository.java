package com.example.APICompletaLabo.jpa;

import com.example.APICompletaLabo.Entities.GameEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GameJpaRepository extends JpaRepository<GameEntity, Long> {

}
