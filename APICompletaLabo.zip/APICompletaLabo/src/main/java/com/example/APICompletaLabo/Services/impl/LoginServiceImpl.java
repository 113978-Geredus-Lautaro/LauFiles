package com.example.APICompletaLabo.Services.impl;

import com.example.APICompletaLabo.Models.Player;
import com.example.APICompletaLabo.Services.LoginService;
import com.example.APICompletaLabo.Services.PlayerService;
import com.example.APICompletaLabo.dtos.login.Credential;
import com.example.APICompletaLabo.dtos.login.CredentialV2;
import com.example.APICompletaLabo.dtos.login.EmailIdentity;
import com.example.APICompletaLabo.dtos.login.UserNameIdentity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;


@Service
public class LoginServiceImpl implements LoginService {

    @Autowired
    private PlayerService playerService;


    //ESTE METODO ES PARA HACER UN LOGIN USANDO EL USERNAME O EL EMAIL
    @Override
    public Player login(Credential credential) {

        //ACA DECIMOS SI EL IDENTITY ES UN USERNAME RETORNA EL METDODO loginWithIdentity Y CASTEAMOS LA IDENTITY COMO
        //UN UserNameIdentity

        if(credential.getIdentity() instanceof UserNameIdentity){
            return loginWithIdentity((UserNameIdentity) credential.getIdentity(), credential.getPassword());
        }
        //Y SI NO ES UN USERNAME CASTEAMOS LA IDENTITY COMO UN EmailIdentity
        else
            return loginWithIdentity((EmailIdentity) credential.getIdentity(), credential.getPassword());
    }


    //ESTE METODO ES PARA UTILIZAR CUALQUIERA (EMAIL O USERNAME) Y QUE SOLO LO IDENTIFIQUE
    @Override
    public Player login(CredentialV2 credential) {
        Player player = playerService.
                getPlayerByUserNameOrEmailAndPassword(credential.getIdentity(),credential.getPassword());
        return updateLastLogin(player);
    }



    //CREAMOS UNOS METODOS QUE RETORNEN EL PLAYER SEGUN EL IDENTITY
    private Player loginWithIdentity(UserNameIdentity userNameIdentity, String password){
        //ACCEDEMOS AL PLAYER SERVICE QUE TIENE ACCESO A LA BASE DE DATOS
        Player player = playerService.getPlayerByUserNameAndPassword(userNameIdentity.getUserName(), password);
        return updateLastLogin(player);
    }

    private Player loginWithIdentity(EmailIdentity emailIdentity, String password){
        //ACCEDEMOS AL PLAYER SERVICE QUE TIENE ACCESO A LA BASE DE DATOS
        Player player =  playerService.getPlayerByEmailAndPassword(emailIdentity.getEmail(), password);
        return updateLastLogin(player);
    }

    //CREAMOS UN METODO PARA ACTUALIZAR LOS LASTLOGIN DE LOS USUARIOS
    private Player updateLastLogin(Player player){
        player.setLastLoginDate(LocalDateTime.now());
        return playerService.savePlayer(player);
    }

}
