package com.example.APICompletaLabo.Services.impl;

import com.example.APICompletaLabo.Entities.PlayerEntity;
import com.example.APICompletaLabo.Models.Match;
import com.example.APICompletaLabo.Models.Player;
import com.example.APICompletaLabo.Services.MatchService;
import com.example.APICompletaLabo.Services.PlayerService;
import com.example.APICompletaLabo.jpa.PlayerJpaRepository;
import jakarta.persistence.EntityNotFoundException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PlayerServiceImpl implements PlayerService {

    @Autowired
    private PlayerJpaRepository jpaPlayerJpaRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public Player getPlayerById(long id) {
        PlayerEntity playerEntity = jpaPlayerJpaRepository.getReferenceById(id);
        Player player = modelMapper.map(playerEntity,Player.class);

        return player;
    }

    @Override
    public Player savePlayer(Player player) {
        Optional<PlayerEntity> playerEntityOptional = jpaPlayerJpaRepository.findByUserNameOrEmail
                (player.getUserName() ,player.getEmail());
        if (playerEntityOptional.isEmpty()){
            PlayerEntity playerEntity = modelMapper.map(player,PlayerEntity.class);
            PlayerEntity playerEntitySaved = jpaPlayerJpaRepository.save(playerEntity);
            return modelMapper.map(playerEntitySaved,Player.class);
        }
        else
            return null;

    }

    @Override
    public Player getPlayerByUserNameAndPassword(String userName, String password) {
         Optional<PlayerEntity> playerEntityOptional =
                 jpaPlayerJpaRepository.findByUserNameAndPassword(userName, password);

         if(playerEntityOptional.isPresent()){
             return modelMapper.map(playerEntityOptional.get(), Player.class);
         }
         else
             throw new EntityNotFoundException("Username or password invalid");
    }

    @Override
    public Player getPlayerByEmailAndPassword(String email, String password) {
        Optional<PlayerEntity> playerEntityOptional =
                jpaPlayerJpaRepository.findByEmailAndPassword(email, password);

        if(playerEntityOptional.isPresent()){
            return modelMapper.map(playerEntityOptional.get(), Player.class);
        }
        else
            throw new EntityNotFoundException("email or password invalid");
    }

    @Override
    public Player getPlayerByUserNameOrEmailAndPassword(String identity, String password) {
        Optional<PlayerEntity> playerEntityOptional =
                jpaPlayerJpaRepository.findByUserNameOrEmailAndPassword(identity,password);
        if(playerEntityOptional.isPresent()){
            return modelMapper.map(playerEntityOptional.get(), Player.class);
        }
        else{
            throw new EntityNotFoundException("Some parameters are incorrect");
        }

    }



}
