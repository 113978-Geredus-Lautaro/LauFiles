package com.example.APICompletaLabo.dtos.login;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@JsonTypeInfo(use = JsonTypeInfo.Id.NAME /* HACE QUE SE DIFERENCIEN LOS TIPOS USERNAME Y EMAIL */,
        property = "identity_type" /* SE IDENTIFICA A TRAVEZ DE ESTA PROPIEDAD */,
        include = JsonTypeInfo.As.EXISTING_PROPERTY /* SIGNIFICA QUE YA ESTA INCLUIDA EN LA CALSE*/,
        visible = true /* DEBE SER VISIBLE*/)


@JsonSubTypes({
        //A LA VEZ SE DELCARAN DOS SUB TIPOS
        @JsonSubTypes.Type(value = UserNameIdentity.class, name = "USERNAME"),
        /* CUANDO VENGA EL NOMBRE POR EL ENUM DE USERNAME SE CREA LA CLASE UserNameIdentity */


        @JsonSubTypes.Type(value = EmailIdentity.class, name = "EMAIL")  })
        /* CUANDO VENGA EL NOMBRE POR EL ENUM DE EMAIL SE CREA LA CLASE EmailIdentity  */

@Data
@AllArgsConstructor
@NoArgsConstructor
public abstract class Identity {

    @NotNull(message = "identity_type can't by null")
    @JsonProperty("identity_type")

    //IDENTIFICA SI ES UN USERNAME O UN EMAIL
    private IdentityType identityType;
}
