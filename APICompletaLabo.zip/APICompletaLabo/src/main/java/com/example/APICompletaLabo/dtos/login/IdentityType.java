package com.example.APICompletaLabo.dtos.login;

public enum IdentityType {

    USERNAME, EMAIL
}
