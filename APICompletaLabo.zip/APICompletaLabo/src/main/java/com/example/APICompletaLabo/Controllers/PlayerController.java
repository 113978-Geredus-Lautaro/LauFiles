package com.example.APICompletaLabo.Controllers;

import com.example.APICompletaLabo.Models.Match;
import com.example.APICompletaLabo.Models.Player;
import com.example.APICompletaLabo.Services.MatchService;
import com.example.APICompletaLabo.Services.PlayerService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/players")
public class PlayerController {

    @Autowired
    private PlayerService playerService;

    @Autowired
    private MatchService matchService;

    @GetMapping("/{id}")
    public ResponseEntity<Player> getById(@PathVariable Long id){
        return ResponseEntity.ok(playerService.getPlayerById(id));
    }

    @PostMapping
    public ResponseEntity<Player> savePlayer(@RequestBody @Valid Player player){
        Player playerSaved = playerService.savePlayer(player);
        if(Objects.isNull(playerSaved)){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Username or Email already exists");
        }
        else
            return ResponseEntity.ok(playerSaved);
    }

    @GetMapping("/{id}/matches")
    public ResponseEntity<List<Match>> getMatchesofPlayer(@PathVariable Long id){
        List<Match> matches = matchService.getMatchesByPlayer(id);
        return ResponseEntity.ok(matches);
    }



}
