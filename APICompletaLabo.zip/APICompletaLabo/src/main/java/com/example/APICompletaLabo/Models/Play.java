package com.example.APICompletaLabo.Models;

public interface Play {
}
