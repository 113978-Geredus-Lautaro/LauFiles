package com.example.APICompletaLabo.dtos.common;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ErrorApi {

    //CLASE QUE ESPECIFICA EL FORMATO EN EL QUE VOY A DEVOLVER LOS ERRORES
    private String timestamp;
    private Integer status;
    private String error;
    private String message;

}
