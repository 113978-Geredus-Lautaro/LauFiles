package com.example.APICompletaLabo.Controllers;

import com.example.APICompletaLabo.Models.Player;
import com.example.APICompletaLabo.Services.LoginService;
import com.example.APICompletaLabo.Services.PlayerService;
import com.example.APICompletaLabo.dtos.login.Credential;
import com.example.APICompletaLabo.dtos.login.CredentialV2;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/login")
public class LoginController {

    @Autowired
    private LoginService loginService;

    @PostMapping("")
    public ResponseEntity<Player> loginPlayer(@RequestBody @Valid Credential credential){
        return ResponseEntity.ok(loginService.login(credential));
    }

    @PostMapping("/V2")
    public ResponseEntity<Player> loginPlayer(@RequestBody @Valid CredentialV2 credential){
        return ResponseEntity.ok(loginService.login(credential));
    }


}
