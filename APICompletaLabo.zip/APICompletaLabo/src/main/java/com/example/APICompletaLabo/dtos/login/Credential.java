package com.example.APICompletaLabo.dtos.login;


import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Credential {

    //CREA UN OBJETO IDENTITY, QUE TRADUCIENDO VA A SER UN OBJETO EMAIL IDENTITY O USERNAME IDENTITY YA QUE LA CLASE
    //IDENTITY ES ABSTRACTA POR LO QUE SOLO SE PUEDEN CREAR OBJETOS QUE EXTIENDAN DE LA CLASE ESA



    @NotNull(message = "identity can't by null")
    private Identity identity;
    @NotNull(message = "password can't by null")
    private String password;
}
