package com.example.APICompletaLabo.Services;

import com.example.APICompletaLabo.Models.Match;
import com.example.APICompletaLabo.Models.Play;
import org.springframework.stereotype.Service;

@Service
public interface PlayMatch<P extends Play, M extends Match> {
    P play(P play, M Match);
}
