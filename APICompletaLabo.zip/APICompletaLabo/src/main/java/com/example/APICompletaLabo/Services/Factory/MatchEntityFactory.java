package com.example.APICompletaLabo.Services.Factory;

import com.example.APICompletaLabo.Entities.MatchEntity;
import com.example.APICompletaLabo.Entities.MatchRpsEntity;
import com.example.APICompletaLabo.Models.Match;
import com.example.APICompletaLabo.Models.rps.MatchRps;

public class MatchEntityFactory {

    public static Class<? extends MatchEntity> getTypeOfMatch(Match match){
        switch (match.getGame().getCode()){
            case "RPS":
                return MatchRpsEntity.class;
            default:
                return MatchRpsEntity.class;
        }
    }
}
