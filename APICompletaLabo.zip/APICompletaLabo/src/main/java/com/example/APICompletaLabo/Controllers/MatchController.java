package com.example.APICompletaLabo.Controllers;

import com.example.APICompletaLabo.Models.Match;
import com.example.APICompletaLabo.Models.Play;
import com.example.APICompletaLabo.Models.Player;
import com.example.APICompletaLabo.Services.MatchService;
import com.example.APICompletaLabo.dtos.matches.MatchDTO;
import com.example.APICompletaLabo.dtos.play.PlayRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Objects;

@RestController
@RequestMapping("/matches")
public class MatchController {


    @Autowired
    private MatchService matchService;

    @GetMapping("{id}")
    public ResponseEntity<Match> getMatchById(@PathVariable Long id){
        Match match = matchService.getMatchById(id);
        if(match != null){
            return ResponseEntity.ok(match);
        }
        else
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST, "The request has an error");
    }

    @PostMapping
    public ResponseEntity<Match> saveMatch(@RequestBody @Valid MatchDTO matchDTO){
        Match matchSaved = matchService.createMatch(matchDTO);
        if(Objects.isNull(matchSaved)){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "The request has an error");
        }
        else
            return ResponseEntity.ok(matchSaved);
    }

    @PostMapping("/{id}/plays/")
    public ResponseEntity<Play> saveMatch(@PathVariable Long id, @RequestBody @Valid PlayRequest playRequest){
        Play play = matchService.play(id,playRequest);
        if(Objects.isNull(playRequest)){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "The request has an error");
        }
        else
            return ResponseEntity.ok(play);
    }
}
