package com.example.APICompletaLabo.jpa;

import com.example.APICompletaLabo.Entities.MatchEntity;
import com.example.APICompletaLabo.Models.Match;
import io.swagger.v3.oas.models.OpenAPI;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface MatchJpaRepository extends JpaRepository<MatchEntity, Long> {

    @Query("Select m From MatchEntity m where  m.player.id = :player_id")
    Optional<List<MatchEntity>> getAllByPlayer(Long player_id);
}
