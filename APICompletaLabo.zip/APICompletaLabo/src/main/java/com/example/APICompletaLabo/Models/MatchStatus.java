package com.example.APICompletaLabo.Models;

public enum MatchStatus {
    STARTED, FINISHED, CANCELED
}
