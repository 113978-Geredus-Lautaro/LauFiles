package com.example.APICompletaLabo.Services.Factory;

import com.example.APICompletaLabo.Models.rps.MatchRps;
import com.example.APICompletaLabo.Models.rps.PlayRps;
import com.example.APICompletaLabo.Services.PlayMatch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PlayStrategyFactory {

    @Autowired
    private PlayMatch<PlayRps, MatchRps> playMatchRps;

    public PlayMatch getPlayStrategy(String gameCode){
        switch (gameCode){
            case "RPS":
                return playMatchRps;
            default:
                return playMatchRps;
        }
    }

}
