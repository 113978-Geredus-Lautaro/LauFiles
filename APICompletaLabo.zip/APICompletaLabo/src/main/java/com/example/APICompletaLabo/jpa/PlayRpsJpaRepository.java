package com.example.APICompletaLabo.jpa;

import com.example.APICompletaLabo.Entities.PlayRpsEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlayRpsJpaRepository extends JpaRepository<PlayRpsEntity, Long> {
}
