package com.example.APICompletaLabo.Services;

import com.example.APICompletaLabo.Models.Player;
import com.example.APICompletaLabo.dtos.login.Credential;
import com.example.APICompletaLabo.dtos.login.CredentialV2;

public interface LoginService {
    Player login (Credential credential);
    Player login (CredentialV2 credential);

}
