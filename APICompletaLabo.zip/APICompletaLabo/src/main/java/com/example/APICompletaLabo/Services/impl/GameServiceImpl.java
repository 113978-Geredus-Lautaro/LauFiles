package com.example.APICompletaLabo.Services.impl;

import com.example.APICompletaLabo.Entities.GameEntity;
import com.example.APICompletaLabo.Models.Game;
import com.example.APICompletaLabo.Services.GameService;
import com.example.APICompletaLabo.jpa.GameJpaRepository;
import jakarta.validation.constraints.Email;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GameServiceImpl implements GameService {

    @Autowired
    private GameJpaRepository gameJpaRepository;

    @Autowired
    private ModelMapper modelMapper;
    @Override
    public Game getGame(Long id) {

        GameEntity gameEntity = gameJpaRepository.getReferenceById(id);
        return modelMapper.map(gameEntity, Game.class);
    }
}
