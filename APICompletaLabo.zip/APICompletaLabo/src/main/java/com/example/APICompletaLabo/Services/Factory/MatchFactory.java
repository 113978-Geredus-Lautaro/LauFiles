package com.example.APICompletaLabo.Services.Factory;

import com.example.APICompletaLabo.Models.Game;
import com.example.APICompletaLabo.Models.Match;
import com.example.APICompletaLabo.Models.MatchStatus;
import com.example.APICompletaLabo.Models.Player;
import com.example.APICompletaLabo.Models.rps.MatchRps;
import com.example.APICompletaLabo.Models.rps.PlayRps;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class MatchFactory {

    //ESTO ES PARA CREAR EL JUEGO
    public static Match createMatch(Player player, Game game){
        switch (game.getCode()){
            case "RPS":
                return createMatchRps(player,game);
            default:
                return new MatchRps();
        }
    }


    // CON ESTO OBTENES EL TIPO DE JUEGO
    public static Class<? extends Match> getTypeOfMatch(String gameCode){

        switch (gameCode){
            case "RPS":
                return MatchRps.class;
            default:
                return MatchRps.class;
        }
    }


    //CON ESTO OBTENES UN JUEGO PIEDRA PAPEL O TIJERA GENERICO
    public static Match createMatchRps(Player player, Game game){
        MatchRps matchRps = (MatchRps) getBasicMatch(player,game);
        matchRps.setNumberOfPlays(3);
        matchRps.setRemainderPlays(3);
        matchRps.setPlayer1Score(0);
        matchRps.setPlayer2Score(0);
        matchRps.setPlays(new ArrayList<PlayRps>());
        return matchRps;
    }

    //CON ESTO OBTENES UN JUEGO GENERICO
    public static Match getBasicMatch(Player player, Game game){
        Match match = getMatchInstance(game.getCode());
        match.setPlayer1(player);
        match.setGame(game);
        match.setCreatedAt(LocalDateTime.now());
        match.setStatus(MatchStatus.STARTED);
        return match;
    }


    //CON ESTO OBTENES EL NEW JUEGO, YA SEA EL PIEDA PAPEL O TIJERAS U OTRO
    public static final Match getMatchInstance(String gameCode){
        switch (gameCode){
            case "RPS":
                return new MatchRps();


         // case "TATETI":
         //       return new TaTeTiRps;


            default:
                return new MatchRps();
        }
    }


}
