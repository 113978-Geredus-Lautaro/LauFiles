package com.example.APICompletaLabo.Services.Factory;

import com.example.APICompletaLabo.Models.Game;
import com.example.APICompletaLabo.Models.Match;
import com.example.APICompletaLabo.Models.Play;
import com.example.APICompletaLabo.Models.Player;
import com.example.APICompletaLabo.Models.rps.MatchRps;
import com.example.APICompletaLabo.Models.rps.PlayRps;
import com.example.APICompletaLabo.dtos.play.PlayRequest;
import com.example.APICompletaLabo.dtos.play.PlayRpsDTO;

public class PlayFactory {

    public static Play getPlayInstance(PlayRequest playRequest, String gameCode){
        switch (gameCode){
            case "RPS":
                return getPlayRpsInstance(playRequest);
            default:
                return getPlayRpsInstance(playRequest);
        }
    }

    private static Play getPlayRpsInstance(PlayRequest playRequest){
        PlayRpsDTO playRpsDTO = (PlayRpsDTO) playRequest;
        PlayRps playRps = new PlayRps();
        playRps.setShapeHandPlayer1(playRpsDTO.getShapeHandPlayer1());
        playRps.setShapeHandPlayer2(playRpsDTO.getShapeHandPlayer2());
        return playRps;
    }
}
