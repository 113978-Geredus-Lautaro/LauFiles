package com.example.APICompletaLabo.Services;

import com.example.APICompletaLabo.Models.Game;
import org.springframework.stereotype.Service;

@Service
public interface GameService {
    Game getGame(Long id);
}
