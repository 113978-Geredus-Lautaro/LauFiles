package com.example.APICompletaLabo.Services;

import com.example.APICompletaLabo.Models.Match;
import com.example.APICompletaLabo.Models.Play;
import com.example.APICompletaLabo.dtos.matches.MatchDTO;
import com.example.APICompletaLabo.dtos.play.PlayRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface MatchService {

    List<Match> getMatchesByPlayer(Long player_id);
    Match createMatch( MatchDTO matchDTO);

    Match getMatchById(Long id);
    Play play(Long matchId, PlayRequest playRequest);

}
